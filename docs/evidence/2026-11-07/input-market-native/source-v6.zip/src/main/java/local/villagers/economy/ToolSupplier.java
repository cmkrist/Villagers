package local.villagers.economy;

import java.util.UUID;

/** One actual understood supplier response, not a paid order, reserved stock or remote availability claim. */
public final class ToolSupplier {
    private UUID supplier;
    private long heard=-1,expires;
    public boolean hear(UUID peer,long now) {
        if(peer==null || now<0 || now>Long.MAX_VALUE-ToolDemand.LIFETIME)return false;
        supplier(now);
        if(now<=heard || supplier!=null && !supplier.equals(peer))return false;
        supplier=peer;heard=now;expires=now+ToolDemand.LIFETIME;return true;
    }
    public UUID supplier(long now) {
        if(now<heard) {supplier=null;heard=-1;}
        if(now>=expires)supplier=null;
        return supplier;
    }
    public void completed() {supplier=null;}
}
