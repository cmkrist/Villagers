package local.villagers.economy;

import java.util.UUID;

/** One short-lived, understood local request. No remote stock query, debt or transferable authority. */
public final class FoodDemand {
    public static final int EXTRA_NUTRITION = 5;
    public static final long LIFETIME = 12000;
    private UUID requester;
    private long observed = -1, expires;

    /** Called only after actual hearing/understanding, willingness and an unsuccessful real handoff. */
    public boolean hear(UUID peer, long now) {
        if (peer == null || now < 0 || now > Long.MAX_VALUE - LIFETIME) return false;
        extraNutrition(now);
        if (now <= observed || requester != null && !requester.equals(peer)) return false;
        requester = peer; observed = now; expires = now + LIFETIME;
        return true;
    }

    public int extraNutrition(long now) {
        if (now < observed) { requester = null; observed = -1; }
        if (now >= expires) requester = null;
        return requester == null ? 0 : EXTRA_NUTRITION;
    }

    public UUID requester(long now) { extraNutrition(now); return requester; }

    /** Only a completed real transfer to the requester fulfills this signal. */
    public void fulfilled(UUID peer) {
        if (peer != null && peer.equals(requester)) requester = null;
    }
    /** Recipient has explicitly declined an offer; this is not a transfer or social reward. */
    public void withdrawn(UUID peer) { if (peer != null && peer.equals(requester)) requester = null; }
}
