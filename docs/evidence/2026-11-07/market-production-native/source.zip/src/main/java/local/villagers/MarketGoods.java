package local.villagers;

import net.minecraft.core.component.DataComponents;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.Container;
import net.minecraft.world.item.ItemStack;

/** Own-inventory affordances, never used to discover partners. Each seller retains its own working reserve. */
final class MarketGoods {
    enum Good { FOOD,HOE }
    private MarketGoods() {}
    static boolean usableHoe(ItemStack stack) {
        return !stack.isEmpty() && stack.is(ItemTags.HOES) && stack.isDamageableItem()
                && stack.getMaxDamage()-stack.getDamageValue()>=16;
    }
    static boolean accepts(Container after,boolean farmer,Good good) {
        return good==Good.FOOD ? FoodInventory.anySlot(after,farmer)>=0 : after.hasAnyMatching(MarketGoods::usableHoe);
    }
    static int offer(Container bag,ItemStack held,boolean farmer,Good good) {
        if(good==Good.FOOD) {
            int best=-1,nutrition=0;
            for(int i=0;i<bag.getContainerSize();i++) {
                var stack=bag.getItem(i);var food=stack.get(DataComponents.FOOD);
                if(!FoodInventory.supported(stack) || food==null || food.nutrition()<=nutrition || FoodInventory.availableCount(stack,farmer)<1)continue;
                var remaining=new net.minecraft.world.SimpleContainer(bag.getContainerSize());
                for(int j=0;j<bag.getContainerSize();j++)remaining.setItem(j,bag.getItem(j).copy());
                remaining.removeItem(i,1);
                if(FoodSupply.deficit(remaining,farmer)==0) {best=i;nutrition=food.nutrition();}
            }
            return best;
        }
        // Keep the actual working hoe. A newly made inventory tool can then be sold to its customer.
        if(usableHoe(held)) {
            for(int i=0;i<bag.getContainerSize();i++)if(usableHoe(bag.getItem(i)))return i;
            return -1;
        }
        // With no working hoe equipped, retain the most durable usable inventory tool.
        int retained=-1,uses=usableHoe(held)?held.getMaxDamage()-held.getDamageValue():-1;
        for(int i=0;i<bag.getContainerSize();i++)if(usableHoe(bag.getItem(i))) {
            var stack=bag.getItem(i);int n=stack.getMaxDamage()-stack.getDamageValue();
            if(n>uses) {retained=i;uses=n;}
        }
        if(uses<0)return -1;
        for(int i=0;i<bag.getContainerSize();i++)if(usableHoe(bag.getItem(i)) && (i!=retained || bag.getItem(i).getCount()>1))return i;
        return -1;
    }
}
