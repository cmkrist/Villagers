package local.villagers.economy;

import java.util.List;
import java.util.Random;
import local.villagers.language.Concept;
import local.villagers.language.Lexicon;
import local.villagers.language.Utterance;
import local.villagers.relations.FoodRequest;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TradePolicyTest {
    @Test void quotesReflectGreedButFearAndLowMoodNeverDiscountConsent() {
        assertEquals(1,TradePolicy.ask(false,false,0,0));assertEquals(2,TradePolicy.ask(true,false,0,0));
        assertEquals(0,TradePolicy.ask(false,true,1,0));assertEquals(0,TradePolicy.ask(false,false,1,.6));
        assertEquals(0,TradePolicy.ask(false,false,-.26,0));assertEquals(0,TradePolicy.ask(false,false,Double.NaN,0));
    }
    @Test void urgentNeedRaisesBoundedBidWhileSellersRetainBodySafety() {
        assertEquals(1,TradePolicy.bid(false,10));assertEquals(2,TradePolicy.bid(false,6));assertEquals(2,TradePolicy.bid(true,16));
        assertTrue(TradePolicy.sellerSafe(13,20,20,.5));assertFalse(TradePolicy.sellerSafe(12,20,20,.5));
        assertFalse(TradePolicy.sellerSafe(16,17,20,.5));assertFalse(TradePolicy.sellerSafe(16,20,20,.75));
    }
    @Test void aQuoteMustCommunicateEveryCoinAndCannotUseIntentToFillMissingWords() {
        var language=Lexicon.invent(new Random(51));
        var twoCoins=List.of(Concept.TRADE,Concept.HOE,Concept.EMERALD,Concept.EMERALD);
        var words=Utterance.of(language,twoCoins,true);
        assertTrue(FoodRequest.understands(words,language,twoCoins.toArray(Concept[]::new)));
        assertFalse(FoodRequest.understands(words,language,Concept.TRADE,Concept.HOE,Concept.EMERALD));
        assertFalse(FoodRequest.understands(words,Lexicon.empty(),twoCoins.toArray(Concept[]::new)));
        assertFalse(FoodRequest.understands(Utterance.of(language,List.of(Concept.YES),true),language,Concept.YES,Concept.TRADE));
    }
}
