package local.villagers;

import net.minecraft.core.component.DataComponents;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class MarketGoodsTest {
    @BeforeAll static void items() {
        WoodCraftingTest.registries();BreadCraftingTest.initializeItemRegistries();
        net.minecraft.core.registries.BuiltInRegistries.ITEM.get(net.minecraft.core.registries.BuiltInRegistries.ITEM.getKey(Items.CARROT)).orElseThrow()
                .bindComponents(DataComponents.COMMON_ITEM_COMPONENTS);
    }
    private static ItemStack bread(int count) {
        var stack=new ItemStack(Items.BREAD,count);stack.set(DataComponents.FOOD,new FoodProperties.Builder().nutrition(5).saturationModifier(.6F).build());return stack;
    }
    @Test void foodSaleLeavesThePersonalEdibleReserveAndIsOnlyARead() {
        var bag=new SimpleContainer(bread(3),new ItemStack(Items.WHEAT,64));
        assertEquals(-1,MarketGoods.offer(bag,ItemStack.EMPTY,false,MarketGoods.Good.FOOD));
        bag.getItem(0).grow(1);
        assertEquals(0,MarketGoods.offer(bag,ItemStack.EMPTY,false,MarketGoods.Good.FOOD));assertEquals(4,bag.countItem(Items.BREAD));
    }
    @Test void rawGrainDoesNotAuthorizeSellingTheLastEdibleRation() {
        var bag=new SimpleContainer(bread(1),new ItemStack(Items.WHEAT,64),new ItemStack(Items.EMERALD,64));
        assertEquals(-1,MarketGoods.offer(bag,ItemStack.EMPTY,true,MarketGoods.Good.FOOD));
    }
    @Test void aFarmerDoesNotPayForASingleRootItMustKeepInsteadOfEat() {
        var carrot=new ItemStack(Items.CARROT);carrot.set(DataComponents.FOOD,new FoodProperties.Builder().nutrition(3).saturationModifier(.6F).build());
        var received=new SimpleContainer(carrot);
        assertFalse(MarketGoods.accepts(received,true,MarketGoods.Good.FOOD));
        assertTrue(MarketGoods.accepts(received,false,MarketGoods.Good.FOOD));
        carrot.grow(1);assertTrue(MarketGoods.accepts(received,true,MarketGoods.Good.FOOD));
        assertFalse(MarketGoods.accepts(new SimpleContainer(new ItemStack(Items.WHEAT,64)),true,MarketGoods.Good.FOOD));
    }
}
