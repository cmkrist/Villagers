package local.villagers;

import local.villagers.economy.FoodDemand;
import local.villagers.economy.TradePolicy;
import local.villagers.learning.LearningMode;
import local.villagers.navigation.WorkJourney;
import local.villagers.navigation.WorkSearch;
import local.villagers.relations.FoodRequest;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.npc.villager.Villager;

/** A stocked producer can offer a meal to its heard paid requester. Preparation never reserves money or forces a sale. */
final class PaidFoodDelivery {
    private PaidFoodDelivery() {}
    static void interrupt(Session s,long now) {
        if(s.paidFoodJourney.active())s.paidFoodJourney.interrupt(now);
        s.paidFoodPeer=null;s.paidFoodSearch.clear();
    }
    static String seek(ServerLevel level,Villager seller,Session s,long now) {
        var id=s.foodDemand.intent(now)==FoodDemand.Intent.TRADE?s.foodDemand.requester(now):null;
        var peer=id!=null && level.getEntity(id) instanceof Villager v?v:null;
        boolean owned=s.paidFoodPeer!=null;
        if(Villagers.LEARNING_MODE==LearningMode.FROZEN || now<s.nextPaidFoodAttempt || peer==null || peer==seller
                || !seller.isAlive() || seller.isBaby() || seller.isSleeping() || seller.isTrading() || seller.isOnFire()
                || seller.isInWater() || seller.getAirSupply()<200 || VillageSurvival.scheduledRest(level,seller)
                || !TradePolicy.sellerSafe(s.mind.foodLevel(),seller.getHealth(),seller.getMaxHealth(),s.mind.fatigue())
                || MarketGoods.offer(seller.getInventory(),seller.getMainHandItem(),AdventureActions.canHarvest(seller),MarketGoods.Good.FOOD)<0
                || !peer.isAlive() || !Villagers.isManaged(peer) || peer.isBaby() || peer.isSleeping() || peer.isTrading()
                || !FoodRequest.mayApproach(seller.distanceToSqr(peer),seller.hasLineOfSight(peer),VillageSurvival.withinHomeRange(level,s.mind,peer.position()))) {
            if(owned)seller.getNavigation().stop();interrupt(s,now);return null;
        }
        if(!id.equals(s.paidFoodPeer)) {interrupt(s,now);s.paidFoodPeer=id;}
        boolean near=FoodRequest.inReach(seller.distanceToSqr(peer),Villagers.config().hearingRadius(),seller.hasLineOfSight(peer) && peer.hasLineOfSight(seller));
        var step=s.paidFoodJourney.advance(id.toString(),now,near,seller.getX(),seller.getY(),seller.getZ());
        if(step==WorkJourney.Step.WAIT)return null;
        if(step==WorkJourney.Step.ARRIVED) {
            seller.getNavigation().stop();s.nextPaidFoodAttempt=now+TradePolicy.COOLDOWN;
            var buyer=Villagers.existingSession(id);
            boolean sold=buyer!=null && LocalTrade.exchange(level,peer,buyer,seller,MarketGoods.Good.FOOD,now);
            if(sold) {
                s.paidFoodDeliveries++;buyer.nextTradeAttempt=now+TradePolicy.COOLDOWN;
                LocalTrade.interrupt(buyer,now);peer.getNavigation().stop();buyer.familyProvisionStarted=0;buyer.craftingProgress.reset();
            }
            interrupt(s,now);return sold?"delivered a paid meal":"local meal offer unavailable";
        }
        if(step==WorkJourney.Step.FAILED) {
            seller.getNavigation().stop();interrupt(s,now);s.nextPaidFoodAttempt=now+WorkJourney.BACKOFF;return null;
        }
        s.action=null;s.before=null;s.succeeded=false;
        if(step==WorkJourney.Step.START) {seller.getNavigation().stop();s.nextPaidFoodPath=now;}
        if(now>=s.nextPaidFoodPath && WorkNavigation.admit(level,now,seller)) {
            s.nextPaidFoodPath=now+40;
            var result=TradeApproach.move(level,seller,s,peer,s.paidFoodSearch);
            if(result==WorkSearch.Step.EXHAUSTED) {
                seller.getNavigation().stop();interrupt(s,now);s.nextPaidFoodAttempt=now+WorkJourney.BACKOFF;return null;
            }
            if(result==WorkSearch.Step.FOUND)s.paidFoodJourney.navigating(id.toString(),now,seller.getX(),seller.getY(),seller.getZ());
        }
        return "bringing prepared food to a paying neighbour";
    }
}
