package local.villagers;

import java.util.List;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** One server-thread exchange of possessed goods for possessed emerald items. No wallet or created output. */
final class TradeMaterials {
    static final class Plan {
        final List<ItemStack> buyerBefore,sellerBefore;
        final SimpleContainer buyerAfter,sellerAfter;
        final ItemStack goods;
        final int price;
        private final Container buyerOwner,sellerOwner;
        private boolean used;
        private Plan(Container buyer,Container seller,SimpleContainer buyerAfter,SimpleContainer sellerAfter,ItemStack goods,int price) {
            buyerBefore=HarvestMaterials.snapshot(buyer);sellerBefore=HarvestMaterials.snapshot(seller);
            buyerOwner=buyer;sellerOwner=seller;
            this.buyerAfter=buyerAfter;this.sellerAfter=sellerAfter;this.goods=goods.copy();this.price=price;
        }
    }
    private TradeMaterials() {}
    private static SimpleContainer copy(Container bag) {
        var out=new SimpleContainer(bag.getContainerSize());
        for(int i=0;i<bag.getContainerSize();i++)out.setItem(i,bag.getItem(i).copy());
        return out;
    }
    static Plan reserve(Container buyer,Container seller,int slot,int price) {
        if(buyer==seller || price<1 || price>2 || slot<0 || slot>=seller.getContainerSize())return null;
        var goods=seller.getItem(slot).copyWithCount(1);
        if(goods.isEmpty() || goods.is(Items.EMERALD))return null;
        var a=copy(buyer);var b=copy(seller);int owed=price;
        for(int i=0;i<a.getContainerSize() && owed>0;i++)if(a.getItem(i).is(Items.EMERALD)) {
            int n=Math.min(owed,a.getItem(i).getCount());a.removeItem(i,n);owed-=n;
        }
        if(owed!=0)return null;
        b.removeItem(slot,1);
        // Both receipts must fit, including any slots freed by the actual payment/offered item.
        if(!a.addItem(goods.copy()).isEmpty() || !b.addItem(new ItemStack(Items.EMERALD,price)).isEmpty())return null;
        return new Plan(buyer,seller,a,b,goods,price);
    }
    static boolean commit(Container buyer,Container seller,Plan plan) {
        if(plan==null || plan.used || buyer!=plan.buyerOwner || seller!=plan.sellerOwner || buyer==seller || !HarvestMaterials.unchanged(buyer,plan.buyerBefore)
                || !HarvestMaterials.unchanged(seller,plan.sellerBefore))return false;
        plan.used=true;
        for(int i=0;i<buyer.getContainerSize();i++)buyer.setItem(i,plan.buyerAfter.getItem(i).copy());
        for(int i=0;i<seller.getContainerSize();i++)seller.setItem(i,plan.sellerAfter.getItem(i).copy());
        return true;
    }
}
