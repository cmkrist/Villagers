package local.villagers;

import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TradeMaterialsTest {
    @BeforeAll static void items() {WoodCraftingTest.registries();BreadCraftingTest.initializeItemRegistries();}
    @Test void realMoneyAndOneActualComponentBearingToolMoveBothWays() {
        var tool=new ItemStack(Items.WOODEN_HOE);tool.set(DataComponents.MAX_DAMAGE,59);tool.set(DataComponents.DAMAGE,17);
        tool.set(DataComponents.CUSTOM_NAME,Component.literal("Earned hoe"));
        var buyer=new SimpleContainer(new ItemStack(Items.EMERALD,3),ItemStack.EMPTY);
        var seller=new SimpleContainer(tool,ItemStack.EMPTY);
        var plan=TradeMaterials.reserve(buyer,seller,0,2);assertNotNull(plan);
        assertEquals(3,buyer.countItem(Items.EMERALD));assertEquals(1,seller.countItem(Items.WOODEN_HOE));
        assertTrue(TradeMaterials.commit(buyer,seller,plan));assertFalse(TradeMaterials.commit(buyer,seller,plan));
        assertEquals(1,buyer.countItem(Items.EMERALD));assertEquals(2,seller.countItem(Items.EMERALD));
        assertEquals(0,seller.countItem(Items.WOODEN_HOE));
        var acquired=buyer.getItem(1);assertTrue(ItemStack.matches(tool,acquired));assertEquals(17,acquired.getDamageValue());
    }
    @Test void actualSpentSlotsCanReceiveTheOtherHalfOfAnExchange() {
        var buyer=new SimpleContainer(new ItemStack(Items.EMERALD));var seller=new SimpleContainer(new ItemStack(Items.BREAD));
        assertTrue(TradeMaterials.commit(buyer,seller,TradeMaterials.reserve(buyer,seller,0,1)));
        assertEquals(1,buyer.countItem(Items.BREAD));assertEquals(1,seller.countItem(Items.EMERALD));
    }
    @Test void eitherFullReceiptOrInsufficientMoneyLeavesBothBagsUntouched() {
        var buyer=new SimpleContainer(new ItemStack(Items.EMERALD,2));var seller=new SimpleContainer(new ItemStack(Items.BREAD));
        assertNull(TradeMaterials.reserve(buyer,seller,0,1));assertEquals(2,buyer.countItem(Items.EMERALD));assertEquals(1,seller.countItem(Items.BREAD));
        buyer=new SimpleContainer(new ItemStack(Items.EMERALD),ItemStack.EMPTY);
        seller=new SimpleContainer(new ItemStack(Items.BREAD,2));
        assertNull(TradeMaterials.reserve(buyer,seller,0,1));assertEquals(1,buyer.countItem(Items.EMERALD));assertEquals(2,seller.countItem(Items.BREAD));
        assertNull(TradeMaterials.reserve(buyer,seller,0,2));
    }
    @Test void eitherStaleInventoryRejectsBeforeTakingAnything() {
        var buyer=new SimpleContainer(new ItemStack(Items.EMERALD,2),ItemStack.EMPTY);
        var seller=new SimpleContainer(new ItemStack(Items.BREAD,4),ItemStack.EMPTY);
        var plan=TradeMaterials.reserve(buyer,seller,0,1);seller.getItem(0).shrink(1);
        assertFalse(TradeMaterials.commit(buyer,seller,plan));assertEquals(2,buyer.countItem(Items.EMERALD));
        plan=TradeMaterials.reserve(buyer,seller,0,1);buyer.getItem(0).shrink(1);
        assertFalse(TradeMaterials.commit(buyer,seller,plan));assertEquals(0,seller.countItem(Items.EMERALD));
    }
    @Test void aPlanCannotChangeOwnersOrReplayEvenIfPriorBalancesReturn() {
        var buyer=new SimpleContainer(new ItemStack(Items.EMERALD));var seller=new SimpleContainer(new ItemStack(Items.BREAD));
        var plan=TradeMaterials.reserve(buyer,seller,0,1);
        assertFalse(TradeMaterials.commit(new SimpleContainer(new ItemStack(Items.EMERALD)),seller,plan));
        assertTrue(TradeMaterials.commit(buyer,seller,plan));
        buyer.setItem(0,new ItemStack(Items.EMERALD));seller.setItem(0,new ItemStack(Items.BREAD));
        assertFalse(TradeMaterials.commit(buyer,seller,plan));
        assertNull(TradeMaterials.reserve(buyer,buyer,0,1));assertNull(TradeMaterials.reserve(buyer,seller,0,0));
        assertNull(TradeMaterials.reserve(buyer,seller,0,3));
    }
}
