package local.villagers;

import local.villagers.mind.Action;
import local.villagers.mind.AgentMind;
import local.villagers.mind.Observation;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.Vec3;

/** Live, in-memory state of one adopted villager. Only touched on the server thread. */
final class Session {
    final AgentMind mind;
    Action action;
    Observation before;
    long started, nextThink, lastTick, nextSave, nextHomeSearch, sleepStarted, nextCropScan;
    BlockPos target, cropTarget, craftingTable;
    long nextCraftScan, breadCrafted;
    String craftingStatus = "idle";
    BlockPos toolTable;
    long toolProductionStarted, toolWorkStarted, lastToolWork, nextToolWork, woodRecipesCrafted, hoesCrafted;
    String toolStatus = "not working";
    BlockPos stationTarget;
    long nextStationScan, nextStationPath, stationTripStarted, stationWorkStarted, lastStationWork, stationRecipesCrafted, tablesBuilt;
    String stationWorkKind, stationStatus = "not working";
    final local.villagers.navigation.RouteProgress stationProgress = new local.villagers.navigation.RouteProgress(80);
    BlockPos hayTarget, workingHay;
    long nextHayScan, hayWorkStarted, lastHayWork;
    local.villagers.family.Courtship.Agreement courtship;
    long nextFamilySignal, nextFamilyReply;
    long nextFamilyAttempt, familyProvisionStarted, nextFamilyProvision;
    boolean familyFoodGoal;
    boolean selfFoodGoal;
    int stockWheatTarget;
    String foodStatus = "not working";
    java.util.UUID foodHelpPeer;
    final local.villagers.navigation.WorkJourney foodHelpJourney=new local.villagers.navigation.WorkJourney();
    long nextFoodHelpScan,nextFoodHelpPath,foodHelpScans,foodHelpRequests,foodHelpPathRejections;
    long foodSharedGiven,foodSharedReceived;
    String foodHelpStatus="not seeking food help";
    BlockPos expansionTarget, expansionWorking;
    long nextExpansionScan, nextExpansionPath, expansionStarted, lastExpansionWork, plotsCultivated;
    String familyStatus = "no recent family encounter";
    java.util.UUID soilJob;
    BlockPos soilWorking;
    long soilStarted,soilWorkStarted,lastSoilWork,nextSoilScan,nextSoilPath,soilGathered,soilDelivered,soilPathQueries,soilPathRejections;
    boolean soilTrip;
    String soilStatus="not working";
    java.util.Map<String,Object> lastSoilReceipt=java.util.Map.of();
    java.util.Map<String,Object> lastSoilPath=java.util.Map.of();
    BlockPos soilPathObjective;
    int soilPathCursor;
    final local.villagers.navigation.RouteProgress soilProgress=new local.villagers.navigation.RouteProgress(80);
    final local.villagers.navigation.WorkJourney farmJourney = new local.villagers.navigation.WorkJourney();
    long nextFarmPath;
    final local.villagers.navigation.WorkJourney restJourney = new local.villagers.navigation.WorkJourney();
    final local.villagers.survival.RestProgress restProgress = new local.villagers.survival.RestProgress();
    long nextRestPath, restPathRejections, groundRests, bedRests;
    String restStatus = "not resting";
    java.util.UUID forestryJob;
    BlockPos forestryTarget;
    BlockPos forestryPathObjective;
    int forestryPathCursor,forestryStandCandidates;
    long forestryPathBatches,forestryPathRejections;
    String forestryLastPath="none";
    long nextForestryScan,nextForestryPath,forestryStarted,forestryWorkStarted,lastForestryWork,propagulesGathered,logsGathered,propagulesPlanted;
    String forestryStatus="not working";
    long leavesCleared,rootsCleared;
    final local.villagers.navigation.RouteProgress forestryProgress=new local.villagers.navigation.RouteProgress(80);
    long nextMeal;
    long nextFoodRequest;
    java.util.UUID familyCompany;
    long nextCompanyScan;
    final local.villagers.navigation.WorkJourney companyJourney = new local.villagers.navigation.WorkJourney();
    long companyScans, companyPathRejections;
    String companyStatus = "not seeking";
    BlockPos rootCropTarget, blockedCraftTable;
    long nextRootCropScan, blockedCraftUntil;
    final local.villagers.navigation.RouteProgress craftingProgress = new local.villagers.navigation.RouteProgress(80);
    /** Position at the last think, for movement exhaustion. */
    Vec3 lastPos;
    boolean succeeded;
    /** Earliest tick for the next unprompted remark, and for the next word a player may teach. */
    long nextSpeech, nextLesson;

    Session(AgentMind mind, long tick) {
        this.mind = mind;
        lastTick = tick;
        // Stagger periodic saves so a whole village does not queue on the same tick.
        nextSave = tick + 1200 + Math.floorMod(mind.id().hashCode(), 1200);
    }
}
