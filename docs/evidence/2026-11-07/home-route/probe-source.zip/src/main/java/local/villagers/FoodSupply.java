package local.villagers;

import net.minecraft.core.component.DataComponents;
import net.minecraft.world.Container;

/** Finite own-food preparation. Body work, stock and recipe inputs are independent of reproductive readiness. */
final class FoodSupply {
    static final int NUTRITION_TARGET = 15;
    static final int MAX_RAW_WHEAT = 9;
    private FoodSupply() {}

    /** Positive native age is an adult birth cooldown, not a reason to stop eating or working. */
    static boolean mayWork(int nativeAge, float health, double fatigue, boolean safeDay) {
        return nativeAge >= 0 && Float.isFinite(health) && health > 0 && Double.isFinite(fatigue)
                && fatigue >= 0 && fatigue < .75 && safeDay;
    }

    /** Remaining nutritional reserve, using actual food components. No item snapshot, mutation or saturation guess. */
    static int deficit(Container inventory, boolean farmer) {
        int missing = NUTRITION_TARGET;
        for (int slot = 0; slot < inventory.getContainerSize(); slot++) {
            var stack = inventory.getItem(slot);
            if (!FoodInventory.supported(stack)) continue;
            var food = stack.get(DataComponents.FOOD);
            if (food == null || food.nutrition() <= 0) continue;
            long nutrition = (long) FoodInventory.availableCount(stack, farmer) * food.nutrition();
            if (nutrition >= missing) return 0;
            missing -= (int) nutrition;
        }
        return missing;
    }

    static boolean update(Session s, boolean canWork, Container inventory, boolean farmer) {
        s.selfFoodGoal = canWork && deficit(inventory, farmer) > 0;
        return s.selfFoodGoal;
    }

    /** Only enough raw input for missing stock, capped per batch. Raw wheat itself is never edible stock. */
    static int wheatTarget(Container inventory, boolean farmer, int breadNutrition) {
        if (breadNutrition <= 0) return 0;
        int missing = deficit(inventory, farmer);
        return (int) Math.min(MAX_RAW_WHEAT, ((missing + (long) breadNutrition - 1) / breadNutrition) * 3);
    }
}
