package local.villagers;

import com.google.gson.GsonBuilder;
import com.mojang.brigadier.CommandDispatcher;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.util.Map;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.storage.LevelResource;

/** Play-copy-only native hook check. Writes the same block state: no supplies, terrain change or actor setters. */
final class ConstructionProbe {
    private ConstructionProbe() {}
    static void register(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("villagers").requires(Commands.hasPermission(Commands.LEVEL_GAMEMASTERS))
                .then(Commands.literal("constructionprobe")
                        .then(Commands.literal("touch").executes(c -> touch(c.getSource(), false)))
                        .then(Commands.literal("touchstation").executes(c -> touch(c.getSource(), true)))));
    }
    private static int touch(CommandSourceStack source, boolean station) {
        if (!DevMode.inWorld(source.getServer(), DevMode.TRIAL_WORLD) || !"play".equals(System.getProperty("villagers.role"))) return 0;
        try {
            var soil = source.getPlayerOrException().blockPosition(); if (!station) soil = soil.below(); var level = source.getLevel();
            boolean before = station ? ConstructionSites.allowsStation(level, soil) : ConstructionSites.allowsFarm(level, soil);
            if (!before) throw new IllegalStateException("Approve this ground cell first");
            var state = level.getBlockState(soil);
            boolean result = level.setBlock(soil, state, Block.UPDATE_ALL);
            boolean after = station ? ConstructionSites.allowsStation(level, soil) : ConstructionSites.allowsFarm(level, soil), unchanged = level.getBlockState(soil).equals(state);
            var report = Map.of("gameTime", level.getGameTime(), "soil", soil.toShortString(), "authorizedBefore", before,
                    "authorizedAfter", after, "blockUnchanged", unchanged, "nativeSetBlockReturned", result);
            var folder = source.getServer().getWorldPath(LevelResource.ROOT).resolve("villagers/construction-evidence"); Files.createDirectories(folder);
            Files.writeString(folder.resolve((station ? "outside-station-touch-" : "outside-touch-") + level.getGameTime() + ".json"),
                    new GsonBuilder().setPrettyPrinting().create().toJson(report), StandardOpenOption.CREATE_NEW);
            VillageTrial.noteIntervention(level, "constructionprobe: outside native same-state block write at " + soil
                    + "; tests conservative permission revocation, no terrain or resource change");
            if (after || !unchanged) throw new IllegalStateException("Outside-edit revocation failed");
            VillagerCommands.tell(source, "Native outside-edit check passed; this ground permission was revoked."); return 1;
        } catch (Exception failure) { VillagerCommands.tell(source, "Construction probe: " + failure.getMessage()); return 0; }
    }
}
