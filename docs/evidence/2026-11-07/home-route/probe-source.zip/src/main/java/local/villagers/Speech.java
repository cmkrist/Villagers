package local.villagers;

import java.nio.file.Path;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.random.RandomGenerator;
import local.villagers.language.Concept;
import local.villagers.language.Glossary;
import local.villagers.language.GlossaryBook;
import local.villagers.language.GlossaryStore;
import local.villagers.language.Lexicon;
import local.villagers.language.Phrases;
import local.villagers.language.Telling;
import local.villagers.language.Utterance;
import local.villagers.learning.LearningMode;
import local.villagers.mind.Episode;
import local.villagers.relations.Gossip;
import local.villagers.relations.FoodRequest;
import local.villagers.relations.Opinion;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.npc.villager.Villager;

/**
 * Villager language in the world: giving villagers a language, speaking to nearby players (each sees the words
 * they understand translated), conversations between villagers (word spread, opinions, gossip, food requests),
 * telling memories, and players teaching words.
 */
final class Speech {
    private static final RandomGenerator RANDOM = new Random(4111);
    /** A villager with no words copies the language of an adopted neighbour within this many blocks. */
    private static final int LANGUAGE_NEIGHBOUR_RADIUS = 64;
    /** How much one heard word strengthens it in a listener's lexicon. */
    private static final double HEARD_STRENGTH = 0.15;
    /** How much one lesson from a fully receptive villager strengthens a taught word. */
    private static final double TAUGHT_STRENGTH = 0.35;
    private static final long TEACH_COOLDOWN_TICKS = 40;
    private static GlossaryBook glossaries;

    private Speech() {}

    static void start(Path villagersRoot) {
        glossaries = new GlossaryBook(new GlossaryStore(villagersRoot), problem -> Villagers.LOG.warn("Glossary: {}", problem));
    }

    static void stop() {
        if (glossaries != null && !glossaries.close(10_000)) Villagers.LOG.error("Glossary saves still pending at shutdown");
        glossaries = null;
    }

    static void join(UUID player) { if (glossaries != null) glossaries.join(player); }
    static void leave(UUID player) { if (glossaries != null) glossaries.leave(player); }
    static void flush() { if (glossaries != null) glossaries.flush(); }

    static Glossary glossary(UUID player) { return glossaries == null ? Glossary.empty(player) : glossaries.get(player); }

    /** Give a villager without words the language of its nearest adopted neighbour, or a new one. */
    static void ensureLanguage(ServerLevel level, Villager v, Session s) {
        if (!s.mind.lexicon().isEmpty()) return;
        Lexicon neighbour = level.getEntitiesOfClass(Villager.class, v.getBoundingBox().inflate(LANGUAGE_NEIGHBOUR_RADIUS),
                        other -> other != v && Villagers.isManaged(other))
                .stream().sorted(Comparator.comparingDouble(v::distanceToSqr))
                .map(other -> Villagers.existingSession(other.getUUID()))
                .filter(other -> other != null && !other.mind.lexicon().isEmpty())
                .map(other -> other.mind.lexicon()).findFirst().orElse(null);
        UUID id = s.mind.id();
        s.mind.lexicon(neighbour != null ? Lexicon.learnFrom(neighbour, RANDOM)
                : Lexicon.invent(new Random(id.getMostSignificantBits() ^ id.getLeastSignificantBits())));
    }

    /**
     * Say something grounded in what the villager is visibly doing. Unprompted remarks respect the speech cooldown;
     * {@code prompted} replies (thanks, answers) are always said.
     */
    static void say(ServerLevel level, Villager v, Session s, Phrases.Situation situation, Concept extra, boolean prompted) {
        List<Concept> concepts = new java.util.ArrayList<>(Phrases.concepts(situation, RANDOM));
        if (extra != null) concepts.add(extra);
        speak(level, v, s, concepts, true, prompted, null);
    }

    /** The caller's finite family budgets cover both offers and replies; courtesy speech cannot starve an invitation. */
    static Utterance familySignal(ServerLevel level, Villager speaker, Session session, boolean reply) {
        return speak(level, speaker, session, List.of(reply ? Concept.YES : Concept.WANT, Concept.FRIEND, Concept.BED),
                false, true, null);
    }

    /** Speak to every player in hearing range; returns the utterance, or null if nothing was said. */
    private static Utterance speak(ServerLevel level, Villager v, Session s, List<Concept> concepts, boolean grounded,
                                   boolean prompted, Villager addressee) {
        long now = level.getGameTime();
        if (!prompted && now < s.nextSpeech) return null;
        Utterance utterance = Utterance.of(s.mind.lexicon(), concepts, grounded);
        if (utterance == null) return null;
        s.nextSpeech = now + 20L * Villagers.config().speechCooldownSeconds();
        String speaker = s.mind.name() + (addressee == null ? "" : " → " + nameOf(addressee));
        for (ServerPlayer player : hearers(level, v)) {
            if (glossaries != null) glossaries.update(player.getUUID(), g -> utterance.teach(g, ambient(player)));
            player.sendSystemMessage(render(speaker, utterance, glossary(player.getUUID())));
        }
        return utterance;
    }

    private static List<ServerPlayer> hearers(ServerLevel level, Villager v) {
        double radius = Villagers.config().hearingRadius();
        return level.getPlayers(p -> p.isAlive() && p.distanceToSqr(v) <= radius * radius);
    }

    /** What else a listener can see that might be what a word means: the item in their hand. */
    private static Set<Concept> ambient(ServerPlayer player) {
        Set<Concept> context = EnumSet.noneOf(Concept.class);
        Concept held = Concept.forItem(BuiltInRegistries.ITEM.getKey(player.getMainHandItem().getItem()).toString());
        if (held != null) context.add(held);
        return context;
    }

    /** "Fern-ab12: kalu food" with understood words plain and unknown words in grey italics. */
    private static Component render(String speaker, Utterance utterance, Glossary glossary) {
        MutableComponent line = Component.literal(speaker + ": ").withStyle(ChatFormatting.GOLD);
        boolean first = true;
        for (Utterance.Segment segment : utterance.render(glossary)) {
            if (!first) line.append(" ");
            first = false;
            line.append(segment.translation() == null
                    ? Component.literal(segment.word()).withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC)
                    : Component.literal(segment.translation().gloss()).withStyle(ChatFormatting.WHITE));
        }
        return line;
    }

    private static String nameOf(Villager villager) {
        Session other = Villagers.existingSession(villager.getUUID());
        return other == null ? "villager" : other.mind.name();
    }

    /**
     * After a successful chat: the speaker passes on a word, may gossip, may tell a memory, and a hungry listener
     * may ask for food. Frozen research controls keep their checkpoint, so nothing is learned in frozen mode.
     */
    static void converse(ServerLevel level, Villager speaker, Session s, Villager listener) {
        Session l = Villagers.existingSession(listener.getUUID());
        if (l == null || Villagers.LEARNING_MODE == LearningMode.FROZEN) return;
        long now = level.getGameTime();
        s.mind.witness(listener.getUUID(), Opinion.Event.CHATTED, now);
        l.mind.witness(speaker.getUUID(), Opinion.Event.CHATTED, now);

        // Words spread: the listener hears the speaker's word for one concept, sometimes mishearing it.
        Concept concept = Concept.values()[RANDOM.nextInt(Concept.values().length)];
        String word = s.mind.lexicon().wordFor(concept);
        if (word != null) l.mind.lexicon(l.mind.lexicon().hear(concept, word, HEARD_STRENGTH, RANDOM));

        if (RANDOM.nextDouble() < Gossip.chance(s.mind.traits())) gossip(level, speaker, s, listener, l, now);
        askForFood(level, speaker, s, listener, l, now);
    }

    private static void gossip(ServerLevel level, Villager speaker, Session s, Villager listener, Session l, long now) {
        // Prefer a memory about a player (reputation), else an opinion of another villager.
        Episode memory = s.mind.episodes().stream()
                .filter(e -> e.kind() == Episode.Kind.HURT_BY_PLAYER || e.kind() == Episode.Kind.PROTECTED_BY_PLAYER
                        || e.kind() == Episode.Kind.RECEIVED_ITEM)
                .reduce((first, second) -> second).orElse(null);
        if (memory != null && memory.subject() != null && RANDOM.nextBoolean()) {
            l.mind.hearAboutPlayer(s.mind.id(), s.mind.playerImpression(memory.subject()));
            Utterance told = speak(level, speaker, s, Telling.concepts(memory), false, false, listener);
            if (told != null) revealToUnderstandingListeners(level, speaker, s, memory, told);
            return;
        }
        Opinion opinion = Gossip.pick(s.mind.opinions().known(), listener.getUUID(), RANDOM);
        if (opinion == null) return;
        l.mind.hearOpinion(s.mind.id(), opinion, now);
        speak(level, speaker, s, List.of(Concept.FRIEND, opinion.regard() > 0 ? Concept.HAPPY : Concept.AFRAID),
                false, false, listener);
    }

    /** Players who overhear a told memory and understand enough of it come to share it. */
    private static void revealToUnderstandingListeners(ServerLevel level, Villager v, Session s, Episode memory, Utterance told) {
        for (ServerPlayer player : hearers(level, v)) {
            if (memory.isKnownBy(player.getUUID())) continue;
            if (told.understoodBy(glossary(player.getUUID())) >= Telling.UNDERSTANDING && s.mind.reveal(memory.id(), player.getUUID()))
                player.sendSystemMessage(Component.literal("You understood: " + VillagerController.describe(level, s, memory, player))
                        .withStyle(ChatFormatting.AQUA));
        }
    }

    /** A hungry listener asks locally; only an understood request can elicit sharing or an explicit refusal. */
    private static void askForFood(ServerLevel level, Villager speaker, Session s, Villager listener, Session l, long now) {
        if (speaker == listener || speaker.level() != level || listener.level() != level
                || !speaker.isAlive() || !listener.isAlive() || speaker.isTrading() || listener.isTrading()
                || speaker.isSleeping() || listener.isSleeping()
                || !FoodRequest.inReach(speaker.distanceToSqr(listener), Villagers.config().hearingRadius(),
                        speaker.hasLineOfSight(listener) && listener.hasLineOfSight(speaker))
                || !FoodRequest.due(now, l.nextFoodRequest, l.mind.hunger(), l.mind.has(local.villagers.genetics.Trait.GLUTTON))) return;
        l.nextFoodRequest = now + FoodRequest.COOLDOWN;
        Utterance request = speak(level, listener, l, List.of(Concept.WANT, Concept.FOOD), true, true, speaker);
        if (!FoodRequest.understands(request, s.mind.lexicon(), Concept.WANT, Concept.FOOD)) return;
        // Unhappy villagers keep their food; happy and generous ones share even with acquaintances.
        boolean warm = s.mind.has(local.villagers.genetics.Trait.GENEROUS) || s.mind.mood().band() == local.villagers.mood.Mood.Band.HAPPY;
        boolean willing = !s.mind.has(local.villagers.genetics.Trait.GREEDY) && !s.mind.mood().low()
                && (warm || s.mind.opinionOf(listener.getUUID()).regard() >= 0.05)
                && s.mind.hunger() < 0.4;
        if (willing) {
            if (VillagerController.giveFood(speaker, listener)) {
                l.mind.witness(speaker.getUUID(), Opinion.Event.SHARED_FOOD, now);
                level.sendParticles(ParticleTypes.HEART, listener.getX(), listener.getY() + 1.8, listener.getZ(), 2, .2, .2, .2, 0);
                speak(level, speaker, s, List.of(Concept.YES, Concept.FOOD), true, true, listener);
            }
            // No food or no receiving capacity is not a deliberate social refusal.
        } else {
            Utterance refusal = speak(level, speaker, s, List.of(Concept.NO), true, true, listener);
            if (!FoodRequest.understands(refusal, l.mind.lexicon(), Concept.NO)) return;
            l.mind.witness(speaker.getUUID(), Opinion.Event.REFUSED, now);
            level.sendParticles(ParticleTypes.ANGRY_VILLAGER, listener.getX(), listener.getY() + 1.8, listener.getZ(), 1, .2, .2, .2, 0);
        }
    }

    /**
     * A player talks to a villager. It greets them, and if it trusts them it tells its newest memory they don't
     * share. The player comes to share it only if they understand enough of the words.
     */
    static void talk(ServerLevel level, Villager v, Session s, ServerPlayer player) {
        say(level, v, s, Phrases.Situation.GREETING, null, true);
        Episode untold = s.mind.untoldTo(player.getUUID());
        if (untold == null) return;
        if (s.mind.playerImpression(player.getUUID()).trust() < 0.2) {
            player.sendSystemMessage(Component.literal(s.mind.name() + " doesn't trust you enough to share more.")
                    .withStyle(ChatFormatting.GRAY));
            return;
        }
        Utterance told = speak(level, v, s, Telling.concepts(untold), false, true, null);
        if (told == null) return;
        if (told.understoodBy(glossary(player.getUUID())) >= Telling.UNDERSTANDING) {
            if (s.mind.reveal(untold.id(), player.getUUID()))
                player.sendSystemMessage(Component.literal("You understood: " + VillagerController.describe(level, s, untold, player))
                        .withStyle(ChatFormatting.AQUA));
        } else {
            player.sendSystemMessage(Component.literal("You don't understand enough of their words yet.").withStyle(ChatFormatting.GRAY));
        }
    }

    enum TeachResult { LEARNED, REINFORCED, COOLDOWN, INVALID }

    /** A player teaches a villager a word for a concept. Receptive villagers learn faster; they repeat it back. */
    static TeachResult teach(ServerLevel level, Villager v, Session s, ServerPlayer player, Concept concept, String word) {
        if (concept == null || !local.villagers.language.Words.valid(word)) return TeachResult.INVALID;
        long now = level.getGameTime();
        if (now < s.nextLesson) return TeachResult.COOLDOWN;
        s.nextLesson = now + TEACH_COOLDOWN_TICKS;
        double strength = TAUGHT_STRENGTH * s.mind.receptivenessTo(player.getUUID());
        s.mind.lexicon(s.mind.lexicon().reinforce(concept, word, strength));
        boolean adopted = word.equals(s.mind.lexicon().wordFor(concept));
        speak(level, v, s, List.of(concept), true, true, null);
        Villagers.persist(s);
        return adopted ? TeachResult.LEARNED : TeachResult.REINFORCED;
    }
}
