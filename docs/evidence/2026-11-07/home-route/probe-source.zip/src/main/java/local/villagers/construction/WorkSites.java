package local.villagers.construction;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.UUID;

/** Explicit finite ground permissions. Unknown land is denied; protection always wins. */
public record WorkSites(int schemaVersion, List<Farm> farms, List<Protection> protections, List<Station> stations) {
    public static final int SCHEMA = 2, MAX_FARMS = 8, MAX_CELLS = 81, MAX_PROTECTIONS = 32, MAX_STATIONS = 8;
    private static final java.util.regex.Pattern DIMENSION = java.util.regex.Pattern.compile("[a-z0-9_.-]+:[a-z0-9_/.-]+");
    public record Point(String dimension, int x, int y, int z) {
        public Point {
            if (dimension == null || dimension.length() > 128 || !DIMENSION.matcher(dimension).matches()
                    || Math.abs((long) x) > 30_000_000 || Math.abs((long) z) > 30_000_000 || y < -2032 || y > 2032)
                throw new IllegalArgumentException("Invalid site position");
        }
        public Point above(int n) { return new Point(dimension, x, y + n, z); }
    }
    public record Farm(UUID id, UUID owner, List<Point> cells) {
        public Farm {
            if (id == null || owner == null || cells == null || cells.isEmpty() || cells.size() > MAX_CELLS)
                throw new IllegalArgumentException("Invalid farm grant");
            cells = List.copyOf(cells);
            if (new HashSet<>(cells).size() != cells.size()) throw new IllegalArgumentException("Duplicate cells");
            Point first = cells.getFirst();
            int minX = cells.stream().mapToInt(Point::x).min().orElseThrow(), maxX = cells.stream().mapToInt(Point::x).max().orElseThrow();
            int minZ = cells.stream().mapToInt(Point::z).min().orElseThrow(), maxZ = cells.stream().mapToInt(Point::z).max().orElseThrow();
            if (maxX - minX > 8 || maxZ - minZ > 8 || cells.stream().anyMatch(p -> !p.dimension().equals(first.dimension())
                    || p.y() != first.y() || p.y() > 2029)) throw new IllegalArgumentException("Farm exceeds bounds");
        }
    }
    public record Protection(UUID id, UUID owner, Point min, Point max) {
        public Protection {
            if (id == null || owner == null || min == null || max == null || !min.dimension().equals(max.dimension()))
                throw new IllegalArgumentException("Invalid protection");
            long x = (long) max.x() - min.x() + 1, y = (long) max.y() - min.y() + 1, z = (long) max.z() - min.z() + 1;
            if (x <= 0 || y <= 0 || z <= 0 || x > 64 || y > 64 || z > 64 || x * y * z > 4096)
                throw new IllegalArgumentException("Protection exceeds bounds");
        }
        public boolean contains(Point p) { return min.dimension().equals(p.dimension()) && p.x() >= min.x() && p.x() <= max.x()
                && p.y() >= min.y() && p.y() <= max.y() && p.z() >= min.z() && p.z() <= max.z(); }
    }
    public record Station(UUID id, UUID owner, Point target) {
        public Station {
            if (id == null || owner == null || target == null || target.y() < -2031 || target.y() > 2031
                    || Math.abs((long) target.x()) >= 30_000_000 || Math.abs((long) target.z()) >= 30_000_000)
                throw new IllegalArgumentException("Invalid station grant");
        }
        /** Only the center may receive a table. Support, headroom and four access cells are watched for edits. */
        public List<Point> footprint() {
            var points = new ArrayList<Point>(); points.add(target.above(-1)); points.add(target); points.add(target.above(1));
            for (int[] d : new int[][] {{-1,0},{1,0},{0,-1},{0,1}}) for (int y = 0; y <= 1; y++)
                points.add(new Point(target.dimension(), target.x() + d[0], target.y() + y, target.z() + d[1]));
            return List.copyOf(points);
        }
    }
    public WorkSites(int schemaVersion, List<Farm> farms, List<Protection> protections) {
        this(schemaVersion, farms, protections, List.of());
    }
    public WorkSites {
        if (schemaVersion == 1 && stations == null) { schemaVersion = SCHEMA; stations = List.of(); }
        if (schemaVersion != SCHEMA || farms == null || protections == null || farms.size() > MAX_FARMS
                || protections.size() > MAX_PROTECTIONS || stations == null || stations.size() > MAX_STATIONS)
            throw new IllegalArgumentException("Unsupported or invalid sites");
        farms = List.copyOf(farms); protections = List.copyOf(protections); stations = List.copyOf(stations);
        var ids = new HashSet<UUID>(); var cells = new HashSet<Point>();
        for (Farm f : farms) {
            if (!ids.add(f.id())) throw new IllegalArgumentException("Duplicate site identity");
            for (Point p : f.cells()) for (int y = 0; y <= 2; y++)
                if (!cells.add(p.above(y))) throw new IllegalArgumentException("Overlapping farm footprints");
        }
        for (Protection p : protections) if (!ids.add(p.id())) throw new IllegalArgumentException("Duplicate site identity");
        for (Station s : stations) {
            if (!ids.add(s.id())) throw new IllegalArgumentException("Duplicate site identity");
            for (Point p : s.footprint()) if (!cells.add(p)) throw new IllegalArgumentException("Overlapping work-site footprints");
        }
    }
    public static WorkSites empty() { return new WorkSites(SCHEMA, List.of(), List.of()); }
    public boolean allows(Point soil) {
        return farms.stream().anyMatch(f -> f.cells().contains(soil)) && !protectedFootprint(soil);
    }
    public boolean protectedFootprint(Point soil) {
        for (Protection p : protections) if (p.min().dimension().equals(soil.dimension())
                && soil.x() >= p.min().x() && soil.x() <= p.max().x()
                && soil.z() >= p.min().z() && soil.z() <= p.max().z()
                && soil.y() <= p.max().y() && soil.y() + 2 >= p.min().y()) return true;
        return false;
    }
    public boolean allowsStation(Point target) {
        return stations.stream().anyMatch(s -> s.target().equals(target)
                && s.footprint().stream().noneMatch(p -> protections.stream().anyMatch(zone -> zone.contains(p))));
    }
    public WorkSites add(Farm f) { var next = new ArrayList<>(farms); next.add(f); return new WorkSites(SCHEMA, next, protections, stations); }
    public WorkSites add(Protection p) { var next = new ArrayList<>(protections); next.add(p); return new WorkSites(SCHEMA, farms, next, stations); }
    public WorkSites add(Station s) { var next = new ArrayList<>(stations); next.add(s); return new WorkSites(SCHEMA, farms, protections, next); }
    public WorkSites remove(UUID id) { return new WorkSites(SCHEMA, farms.stream().filter(f -> !f.id().equals(id)).toList(),
            protections.stream().filter(p -> !p.id().equals(id)).toList(), stations.stream().filter(s -> !s.id().equals(id)).toList()); }
    /** An outside block edit or a completed plot retires this finite permission, including its headroom. */
    public WorkSites touch(Point block) {
        var next = new ArrayList<Farm>();
        for (Farm f : farms) {
            var cells = f.cells().stream().filter(p -> !p.equals(block) && !p.above(1).equals(block) && !p.above(2).equals(block)).toList();
            if (!cells.isEmpty()) next.add(new Farm(f.id(), f.owner(), cells));
        }
        return new WorkSites(SCHEMA, next, protections, stations.stream().filter(s -> !s.footprint().contains(block)).toList());
    }
    public WorkSites revokeEdits() { return new WorkSites(SCHEMA, List.of(), protections, List.of()); }
}
