package local.villagers.navigation;

/** One bounded remembered-worksite trip. A new path does not reset physical progress or total deadline. */
public final class WorkJourney {
    public static final long TIMEOUT = 400, BACKOFF = 400;
    public enum Step { WAIT, START, TRAVEL, ARRIVED, FAILED }
    private final RouteProgress progress = new RouteProgress(80);
    private String goal;
    private long started, nextAllowed, lastTick;
    public boolean active() { return goal != null; }

    public Step advance(String target, long now, boolean arrived, double x, double y, double z) {
        if (now < 0) throw new IllegalArgumentException("Invalid work clock");
        if (now < lastTick) { goal = null; nextAllowed = now; progress.reset(); }
        lastTick = now;
        if (target == null) { interrupt(now); return Step.WAIT; }
        if (goal != null && !goal.equals(target)) { goal = null; progress.reset(); }
        if (goal == null) {
            if (now < nextAllowed) return Step.WAIT;
            if (arrived) { nextAllowed = now + BACKOFF; return Step.ARRIVED; }
            goal = target; started = now; progress.reset();
            progress.stalled(goal, now, x, y, z);
            return Step.START;
        }
        if (arrived) { reject(now); return Step.ARRIVED; }
        if (now - started >= TIMEOUT || progress.stalled(goal, now, x, y, z)) {
            reject(now); return Step.FAILED;
        }
        return Step.TRAVEL;
    }

    public void reject(long now) { goal = null; nextAllowed = now + BACKOFF; progress.reset(); }
    public void interrupt(long now) { goal = null; nextAllowed = Math.max(nextAllowed, now + 40); progress.reset(); }
}
