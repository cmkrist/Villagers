package local.villagers;

import local.villagers.mind.MealPolicy;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.Container;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Read-only inventory affordances; selecting a ration never consumes stock or the last planting root. */
final class FoodInventory {
    private FoodInventory() {}

    static boolean supported(ItemStack item) {
        return item.has(DataComponents.FOOD) && (item.is(Items.BREAD) || item.is(Items.CARROT)
                || item.is(Items.POTATO) || item.is(Items.BEETROOT));
    }

    static boolean fits(ItemStack item, int food, float health, float maxHealth) {
        var properties = item.get(DataComponents.FOOD);
        return supported(item) && properties != null
                && MealPolicy.shouldEat(food, properties.nutrition(), health, maxHealth);
    }

    static int availableCount(ItemStack item, boolean farmer) {
        return Math.max(0, item.getCount() - (farmer && (item.is(Items.CARROT) || item.is(Items.POTATO)) ? 1 : 0));
    }

    static int anySlot(Container inventory, boolean farmer) {
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack item = inventory.getItem(i);
            if (supported(item) && availableCount(item, farmer) > 0) return i;
        }
        return -1;
    }

    static int mealSlot(Container inventory, boolean farmer, int food, float health, float maxHealth) {
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack item = inventory.getItem(i);
            if (availableCount(item, farmer) > 0 && fits(item, food, health, maxHealth)) return i;
        }
        return -1;
    }
}
