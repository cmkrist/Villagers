package local.villagers;

import local.villagers.navigation.WorkJourney;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;

/** Return to a real native remembered composter; this is not knowledge of unobserved crops. */
final class FarmWorksite {
    private FarmWorksite() {}
    static void interrupt(Session s, long now) { s.farmJourney.interrupt(now); }

    static String travel(ServerLevel level, Villager v, Session s, long now) {
        var memory = v.getBrain().getMemory(MemoryModuleType.JOB_SITE);
        BlockPos site = memory.filter(p -> p.dimension().equals(level.dimension())).map(p -> p.pos()).orElse(null);
        boolean stock = v.getInventory().hasAnyMatching(item -> item.is(Items.WHEAT_SEEDS) || item.is(Items.CARROT)
                || item.is(Items.POTATO) || item.is(Items.BEETROOT_SEEDS));
        if (!AdventureActions.canHarvest(v) || !stock || site == null || !level.isLoaded(site)
                || !level.getBlockState(site).is(Blocks.COMPOSTER)
                || !VillageSurvival.withinHomeRange(level, s.mind, Vec3.atCenterOf(site))
                || v.position().distanceToSqr(Vec3.atCenterOf(site)) > 1024) {
            interrupt(s, now); return null;
        }
        boolean wasTravelling = s.farmJourney.active();
        WorkJourney.Step step = s.farmJourney.advance(site.toShortString(), now,
                v.position().distanceToSqr(Vec3.atCenterOf(site)) <= 4, v.getX(), v.getY(), v.getZ());
        if (step == WorkJourney.Step.WAIT) return null;
        s.action = null; s.before = null; s.succeeded = false;
        if (step == WorkJourney.Step.ARRIVED || step == WorkJourney.Step.FAILED) {
            v.getNavigation().stop(); s.nextCropScan = now; s.nextCraftScan = now;
            s.foodStatus = step == WorkJourney.Step.ARRIVED ? "checking remembered farm" : "remembered farm route stalled";
            if (step == WorkJourney.Step.ARRIVED && wasTravelling) s.mind.remember("Arrived at remembered farm " + site.toShortString());
            if (step == WorkJourney.Step.FAILED) s.mind.remember("Stopped farm trip without arriving at " + site.toShortString());
            return s.foodStatus;
        }
        if (step == WorkJourney.Step.START) {
            s.mind.remember("Planned trip to remembered farm " + site.toShortString());
            v.getNavigation().stop(); s.action = null; s.before = null; s.succeeded = false;
            s.nextFarmPath = now;
        }
        if (now >= s.nextFarmPath && WorkNavigation.admit(level, now)) {
            s.nextFarmPath = now + 40;
            var path = v.getNavigation().createPath(site, 1);
            if (!WorkNavigation.staysHome(level, v, s, path)) {
                s.farmJourney.reject(now); v.getNavigation().stop();
                s.mind.remember("No permitted route to remembered farm " + site.toShortString());
                s.foodStatus = "remembered farm unreachable"; return s.foodStatus;
            }
            v.getNavigation().moveTo(path, .65);
        }
        s.foodStatus = "returning to remembered farm";
        return s.foodStatus;
    }
}
