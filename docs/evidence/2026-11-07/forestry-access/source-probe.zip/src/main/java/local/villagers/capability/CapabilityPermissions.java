package local.villagers.capability;

import java.util.Set;

/** Immutable permissions: specific food operations are separate exceptions to terrain editing. */
public final class CapabilityPermissions {
    public enum Capability { OPEN_DOOR, CLOSE_DOOR, CONSUME_FOOD, EQUIP_ITEM, DEFENSIVE_MELEE, HARVEST_REPLANT, CRAFT_BREAD, GATHER_HAY, UNPACK_HAY, CULTIVATE_PLANT, CRAFT_WOODEN_HOE, BUILD_CRAFTING_TABLE, FORESTRY, BREAK_BLOCK, PLACE_BLOCK }
    private static final CapabilityPermissions ADVENTURE = new CapabilityPermissions(Set.of(
        Capability.OPEN_DOOR, Capability.CLOSE_DOOR, Capability.CONSUME_FOOD,
        Capability.EQUIP_ITEM, Capability.DEFENSIVE_MELEE, Capability.HARVEST_REPLANT, Capability.CRAFT_BREAD,
        Capability.GATHER_HAY, Capability.UNPACK_HAY, Capability.CULTIVATE_PLANT, Capability.CRAFT_WOODEN_HOE, Capability.BUILD_CRAFTING_TABLE, Capability.FORESTRY));
    private final Set<Capability> allowed;

    private CapabilityPermissions(Set<Capability> allowed) { this.allowed = Set.copyOf(allowed); }
    public static CapabilityPermissions adventure() { return ADVENTURE; }
    public boolean allows(Capability capability) { return allowed.contains(capability); }
    public Set<Capability> allowed() { return allowed; }
}
