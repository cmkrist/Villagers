package local.villagers;

import java.util.IdentityHashMap;
import java.util.Map;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.level.pathfinder.Path;
import net.minecraft.world.phys.Vec3;

/** Shared work-path admission: at most two bounded planning batches per dimension/second. */
final class WorkNavigation {
    private static final Map<ServerLevel, Long> NEXT = new IdentityHashMap<>();
    private WorkNavigation() {}
    static void clear() { NEXT.clear(); }
    static boolean admit(ServerLevel level, long now) {
        if (now < NEXT.getOrDefault(level, 0L)) return false;
        NEXT.put(level, now + 10); return true;
    }
    static boolean staysHome(ServerLevel level, Villager v, Session s, Path path) {
        if (path == null || !path.canReach() || path.getNodeCount() > 128) return false;
        for (int i = 0; i < path.getNodeCount(); i++) {
            var pos = path.getNodePos(i);
            if (!VillageSurvival.withinHomeRange(level, s.mind, new Vec3(pos.getX() + .5, pos.getY(), pos.getZ() + .5))) return false;
        }
        return true;
    }
}
