package local.villagers;

import local.villagers.capability.CapabilityPermissions.Capability;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.item.crafting.RecipeType;

/** Replace a missing farm tool using possessed wood and a reachable existing table. No supplied outputs. */
final class ToolProduction {
    private ToolProduction() {}
    static void interrupt(Session s) { s.toolProductionStarted = 0; s.toolWorkStarted = 0; s.toolTable = null; }
    private static boolean eligible(ServerLevel level, Villager v, Session s) {
        return AdventureActions.PERMISSIONS.allows(Capability.CRAFT_WOODEN_HOE) && !AdventureActions.canHarvest(v)
                && FoodSupply.mayWork(v.getAge(), v.getHealth(), s.mind.fatigue(),
                !level.isDarkOutside() && !v.isSleeping() && !v.isTrading() && !v.isInWater()
                        && !v.isOnFire() && v.getAirSupply() >= 200)
                && v.getInventory().hasAnyMatching(PlantingMaterials::supported);
    }
    static String work(ServerLevel level, Villager v, Session s, long now) {
        if (!eligible(level, v, s)) {
            interrupt(s); return null;
        }
        if (now < s.nextToolWork) return null;
        if (WoodCrafting.next(v.getInventory()) == null) {
            interrupt(s); s.nextToolWork = now + 100; s.toolStatus = "missing wood for a hoe"; return null;
        }
        BlockPos table = BreadCrafting.table(level, v, s);
        if (table == null) {
            interrupt(s); s.nextToolWork = now + 100; s.toolStatus = "hoe needs an existing crafting table"; return null;
        }
        if (s.toolProductionStarted != 0 && (now < s.lastToolWork || now - s.lastToolWork > 10
                || !table.equals(s.toolTable))) interrupt(s);
        if (s.toolProductionStarted == 0) {
            s.toolProductionStarted = now; s.toolTable = table; s.craftingProgress.reset();
        }
        if (now - s.toolProductionStarted >= 400) {
            interrupt(s); v.getNavigation().stop(); s.nextToolWork = now + 400;
            s.toolStatus = "hoe production route timed out"; return null;
        }
        s.lastToolWork = now;
        s.action = null; s.before = null; s.succeeded = false;
        if (!BreadCrafting.canWorkAt(level, v, s, table)) {
            s.toolWorkStarted = 0;
            BreadCrafting.approach(level, v, s, table, now);
            s.toolStatus = "approaching table to make a hoe"; return s.toolStatus;
        }
        v.getNavigation().stop();
        if (s.toolWorkStarted == 0) s.toolWorkStarted = now;
        if (now - s.toolWorkStarted >= 20) {
            boolean made = craft(level, v, s, table);
            s.toolWorkStarted = 0;
            if (!made) { interrupt(s); s.nextToolWork = now + 200; return null; }
            if (AdventureActions.canHarvest(v)) { interrupt(s); s.nextToolWork = now + 100; }
        }
        return s.toolStatus = AdventureActions.canHarvest(v) ? "made a real wooden hoe" : "working wood for a hoe";
    }
    static boolean craft(ServerLevel level, Villager v, Session s, BlockPos table) {
        if (!eligible(level, v, s) || !BreadCrafting.canWorkAt(level, v, s, table)) return false;
        var plan = WoodCrafting.next(v.getInventory());
        if (plan == null) return false;
        var recipe = level.recipeAccess().getRecipeFor(RecipeType.CRAFTING, plan.input(), level);
        if (recipe.isEmpty()) { s.toolStatus = "wood recipe unavailable"; return false; }
        var rule = recipe.get().value();
        var output = rule.assemble(plan.input());
        if (rule.getRemainingItems(plan.input()).stream().anyMatch(stack -> !stack.isEmpty())
                || !eligible(level, v, s) || !BreadCrafting.canWorkAt(level, v, s, table)
                || !WoodCrafting.commit(v.getInventory(), plan, output)) {
            s.toolStatus = "wood recipe or output blocked"; return false;
        }
        s.woodRecipesCrafted++;
        if (plan.step() == WoodCrafting.Step.HOE) {
            s.hoesCrafted++;
            AdventureActions.prepareHoeForWork(level, v);
        }
        v.swingForAttack(InteractionHand.MAIN_HAND);
        s.mind.remember("Crafted " + output.getCount() + " " + BuiltInRegistries.ITEM.getKey(output.getItem())
                + " from owned wood using native recipe at " + table.toShortString());
        Villagers.persist(s);
        return true;
    }
}
