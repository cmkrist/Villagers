package local.villagers.economy;

import java.util.UUID;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class FoodDemandTest {
    @Test void duplicateAndCrowdedRequestsCannotAccumulateProductionDebt() {
        var signal = new FoodDemand(); var peer = new UUID(1, 1);
        assertEquals(0, signal.extraNutrition(100));
        assertTrue(signal.hear(peer, 100));
        assertFalse(signal.hear(peer, 100));
        for (int i = 2; i < 100; i++) assertFalse(signal.hear(new UUID(1, i), 101));
        assertEquals(5, signal.extraNutrition(101));
    }

    @Test void expiredOrRewoundSignalsDoNotDriveWorkAndNewHearingCanWakeIt() {
        var signal = new FoodDemand(); var peer = new UUID(2, 1);
        signal.hear(peer, 100);
        assertEquals(5, signal.extraNutrition(2499));
        assertEquals(0, signal.extraNutrition(2500));
        assertTrue(signal.hear(peer, 3000));
        assertEquals(0, signal.extraNutrition(20));
        assertTrue(signal.hear(peer, 30));
    }

    @Test void anotherActualRequestRefreshesOnlyTheSameBoundedReserve() {
        var signal = new FoodDemand(); var peer = new UUID(3, 1);
        signal.hear(peer, 100);
        assertTrue(signal.hear(peer, 700));
        assertEquals(5, signal.extraNutrition(2500));
        assertEquals(0, signal.extraNutrition(3100));
    }

    @Test void onlyActualTransferToTheRequestingNeighbourFulfillsTheSignal() {
        var signal = new FoodDemand(); var peer = new UUID(4, 1);
        signal.hear(peer, 100);
        signal.fulfilled(new UUID(4, 2)); assertEquals(5, signal.extraNutrition(200));
        signal.fulfilled(peer); assertEquals(0, signal.extraNutrition(200));
        assertFalse(signal.hear(null, 200)); assertFalse(signal.hear(peer, -1));
        assertFalse(signal.hear(peer, Long.MAX_VALUE));
    }

    @Test void replayOfAFulfilledRequestCannotCreateAnotherProductionGoal() {
        var signal = new FoodDemand(); var peer = new UUID(5, 1);
        assertTrue(signal.hear(peer, 0));
        signal.fulfilled(peer);
        assertFalse(signal.hear(peer, 0));
        assertEquals(0, signal.extraNutrition(0));
        assertTrue(signal.hear(peer, 600), "A later real request is a new signal");
    }
}
